# Vu MultiTool
# Providing A Plethora of Local Host and Internet Wide Utilites
# Personal Info Lookup Module

import sys
import os
import time
import socket
import random
import struct
import urllib
import json

global aa,ab,ac,ad

global _apiKey
_apiKey = str("AIzaSyC-oSFL0qwN7LPjwSajs6R4isUmBYokroM")
global api_key, api_baseURL
api_key = str("a7c2af7ec95057894d8646bd715d76e2")
api_baseURL = str("http://api.ipstack.com/")
'''
https://maps.googleapis.com/maps/api/place/nearbysearch/json?location=39.4099197388,-76.4595413208&radius=500&types=food&name=icecream&key=AIzaSyC-oSFL0qwN7LPjwSajs6R4isUmBYokroM
'''

def startProgress(title):
    global progress_x
    sys.stdout.write(title + " -> [" + "-"*45 + "]" + chr(8)*46)
    sys.stdout.flush()
    progress_x = 0

def progress(x,y):
    global progress_x
    x = int(x * 45 // y)
    sys.stdout.write("#" * (x - progress_x))
    sys.stdout.flush()
    progress_x = x

def endProgress():
    sys.stdout.write("#" * (45 - progress_x) + "]\n")
    sys.stdout.flush()

def multi_cis_main():
    print("-- -- -- -- -- -- --   Vu MultiTool   -- -- -- -- -- -- --")
    print('-- -- -- -- --    Closest Icecream Store    -- -- -- -- --\n')
    _ip = raw_input("Enter IP Address   ->  ")
    startProgress("LOOKUP")
    progress(1,8)
    response = urllib.urlopen(api_baseURL+_ip+"?access_key="+api_key+"&output=json")
    _apiData = json.loads(response.read())
    _long = _apiData['longitude']
    _lat  = _apiData['latitude']
    progress(3,8)
    __baseurl = str("https://maps.googleapis.com/maps/api/place/nearbysearch/json?location=__a__,__b__&radius=3000&types=food&name=icecream&key=AIzaSyC-oSFL0qwN7LPjwSajs6R4isUmBYokroM")
    __baseurl = __baseurl.replace('__b__', str(_long))
    __baseurl = __baseurl.replace('__a__', str(_lat))
    _res = urllib.urlopen(__baseurl)
    _moreData = json.loads(_res.read())
    progress(5,8)
    results = _moreData["results"]
    def compDist(hlo,hla,tlo,tla):
        # Rank distance by the Compound Distance Ratio
        if(hlo > tlo):
            aa = hlo - tlo 
        else:
            aa = tlo - hlo 
        if(hla > tla):
            ab = hla - tla 
        else:
            ab = tla - hla 
        return aa+ab
    arro = {}
    for x in range(0, len(results)):
        arro.update({x: compDist(_long,_lat, float(results[x]["geometry"]["location"]["lng"]),float(results[x]["geometry"]["location"]["lat"]))})
    minVal = min(arro, key=arro.get)
    progress(6,8)
    ADDRESS = results[minVal]["vicinity"]
    NAME    = results[minVal]["name"]
    printstr = "LOOKUP -> Completed!\nLOOKUP -> The closest icecream store is "+NAME+" at "+ADDRESS 
    endProgress()
    print(printstr)
    

    