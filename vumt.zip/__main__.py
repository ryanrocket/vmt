#!/usr/bin/env python
# file ./__main__.py
# Vu MultiTool
# Providing A Plethora of Local Host and Internet Wide Utilites

import sys
import os
import time
import socket
import random
from multi_lds import multi_lds_main
from multi_lps import multi_lps_main
from multi_gip import multi_gip_main
from multi_ips import multi_ips_main
from multi_sps import multi_sps_main
from multi_sip import multi_sip_main
from multi_ril import multi_ril_main
from multi_glp import multi_glp_main
from multi_cis import multi_cis_main

from datetime import datetime
now = datetime.now()

_options = {1: 'lds', 2: 'lps', 3: 'gip', 4: 'ips', 5: 'sps', 6: 'sip', 7: 'ril', 8: 'glp', 9: 'cis'}
_probable = ""
_option = ""

def main():
    os.system('clear')
    print("-- -- -- -- -- -- --   Vu MultiTool   -- -- -- -- -- -- --")
    print("[1] Local DoS Attack          [2] Local Port Scan         ")
    print("[3] Get IP From Hostname      [4] Change MAC Address      ")
    print("[5] SQL Port Data Scan        [6] IP Scanner (In Range)   ")
    print("[7] Reverse IP Lookup         [8] Geolocate Personal Info ")
    print("[9] Closest Icecream Store!   [10] Coming Soon...")
    print('\n')
    def _insertOpt(a):
        globals()[a]()

    def _getOpt():
        _tmpOption = input("Selection ->   ")
        _probable  = "multi_"+_options[_tmpOption]+"_main"
        _option    = _options[_tmpOption]
        os.system('clear')
        _insertOpt(_probable)

    _getOpt()

if __name__ == '__main__':
  main()