# Vu MultiTool
# Providing A Plethora of Local Host and Internet Wide Utilites
# Local IP Scanner Module

import sys
import os
import time
import socket
import random
import struct
import threading
import subprocess

global _openPorts

def startProgress(title):
    global progress_x
    sys.stdout.write(title + " -> [" + "-"*45 + "]" + chr(8)*46)
    sys.stdout.flush()
    progress_x = 0

def progress(x,y):
    global progress_x
    x = int(x * 45 // y)
    sys.stdout.write("#" * (x - progress_x))
    sys.stdout.flush()
    progress_x = x

def endProgress():
    sys.stdout.write("#" * (45 - progress_x) + "]\n")
    sys.stdout.flush()

def multi_ips_main():
    print("-- -- -- -- -- -- --   Vu MultiTool   -- -- -- -- -- -- --")
    print('-- -- -- -- -- --   Change MAC Address   -- -- -- -- -- --\n')
    rom = raw_input("Random or Manual [r/m]   ->  ")
    print('[-] WARNING: May Require SUDO Permission')
    subprocess.call(["sudo", "echo", "ACCESS GRANTED"])
    startProgress("CHANGING")
    def random_mac(interface):
        create_random_mac = "02:00:00:%02x:%02x:%02x" % (random.randint(0, 255), random.randint(0, 255), random.randint(0, 255))
        progress(1,5)
        #subprocess.call(["sudo", "ifconfig", interface, "down"])
        progress(2,5)
        subprocess.call(["sudo", "ifconfig", interface, "ether", create_random_mac])
        progress(3,5)
        #subprocess.call(["sudo", "ifconfig", interface, "up"])
        progress(4,5)
        global RANDOM_MAC
        RANDOM_MAC = create_random_mac
        endProgress()
        print("CHANGING -> [COMPLETE] New MAC Address is "+RANDOM_MAC)
    def change_mac(interface, new_mac):
        #subprocess.call(["sudo", "ifconfig", interface, "down"])
        progress(1,3)
        subprocess.call(["sudo", "ifconfig", interface, "ether", new_mac])
        progress(2,3)
        #subprocess.call(["sudo", "ifconfig", interface, "up"])
        endProgress()
        print("CHANGING -> [COMPLETE] New MAC Address is "+new_mac)

    if(rom == "r" or rom == "R"):
        random_mac('en0')
    else:
        aaa = raw_input("Enter MAC Address        ->  ")
        change_mac('en0', aaa)
