# Vu MultiTool
# Providing A Plethora of Local Host and Internet Wide Utilites
# Reverse IP Lookup Module

import sys
import os
import time
import socket
import random
import urllib
import json

global api_key, api_baseURL
api_key = str("a7c2af7ec95057894d8646bd715d76e2")
api_baseURL = str("http://api.ipstack.com/")

def startProgress(title):
    global progress_x
    sys.stdout.write(title + " -> [" + "-"*45 + "]" + chr(8)*46)
    sys.stdout.flush()
    progress_x = 0

def progress(x,y):
    global progress_x
    x = int(x * 45 // y)
    sys.stdout.write("#" * (x - progress_x))
    sys.stdout.flush()
    progress_x = x

def endProgress():
    sys.stdout.write("#" * (45 - progress_x) + "]\n")
    sys.stdout.flush()

def multi_ril_main():
    print("-- -- -- -- -- -- --   Vu MultiTool   -- -- -- -- -- -- --")
    print('-- -- -- -- -- --   Reverse IP Lookup    -- -- -- -- -- --\n')
    _address = raw_input("Enter IP Address   ->  ")
    print("\nLOOKUP -> Please Note: Location data is only precise to a city")
    print("LOOKUP ->              Refer to option 8 for further searching\n")
    _apiFinal = api_baseURL + _address + "?access_key=" + api_key + "&output=json"
    startProgress("LOOKUP")
    progress(1,5)
    response = urllib.urlopen(_apiFinal)
    _apiData = json.loads(response.read())
    time.sleep(0.8)
    progress(2,5)
    # IMPORTANT INFO: "country_name", "region_name", "city", "zip", "longitude", "latitude"
    _printStrPass = "LOOKUP -> Successfully pulled location data!\n"
    _printStrFail = "LOOKUP -> Unable to geolocate (?)\n"
    try:
        if(_apiData["city"] == "None" or _apiData["city"] == None):
            endProgress()
            print(_printStrFail)
        else:
            _printFinal = "------------------LOCATION-DATA------------------"+"\n| Country   ->  " + _apiData["country_name"]+"\n| Region    ->  " + _apiData["region_name"]+"\n| City      ->  " + _apiData["city"]+"\n| Zip Code  ->  " + str(_apiData["zip"])+"\n| Longitude ->  " + str(_apiData["longitude"])+"\n| Latitude  ->  " + str(_apiData["latitude"])+"\n-------------------------------------------------"
            time.sleep(0.5)
            progress(4,5)
            time.sleep(0.4)
            endProgress()
            print(_printStrPass)
            time.sleep(1.4)
            print(_printFinal)
    except:
        _printFinal = "------------------LOCATION-DATA------------------"+"\n| Country   ->  " + _apiData["country_name"]+"\n| Region    ->  " + _apiData["region_name"]+"\n| City      ->  " + _apiData["city"]+"\n| Zip Code  ->  " + str(_apiData["zip"])+"\n| Longitude ->  " + str(_apiData["longitude"])+"\n| Latitude  ->  " + str(_apiData["latitude"])+"\n-------------------------------------------------"
        time.sleep(0.5)
        progress(4,5)
        time.sleep(0.4)
        endProgress()
        print(_printStrPass)
        time.sleep(1.4)
        print(_printFinal)

