# Vu MultiTool
# Providing A Plethora of Local Host and Internet Wide Utilites
# IP Scanner Module

import sys
import os
import time
import socket
import random
import struct

def startProgress(title):
    global progress_x
    sys.stdout.write(title + " -> [" + "-"*45 + "]" + chr(8)*46)
    sys.stdout.flush()
    progress_x = 0

def progress(x,y):
    global progress_x
    x = int(x * 45 // y)
    sys.stdout.write("#" * (x - progress_x))
    sys.stdout.flush()
    progress_x = x

def endProgress():
    sys.stdout.write("#" * (45 - progress_x) + "]\n")
    sys.stdout.flush()

def multi_sip_main():
    print("-- -- -- -- -- -- --   Vu MultiTool   -- -- -- -- -- -- --")
    print('-- -- -- -- -- --    Local IP Scanner    -- -- -- -- -- --')
    print("-- --   Example: 192.168.1.1-255 or 192.168.1.0/24   -- --\n")
    _attackAddress = raw_input("Enter IP Address Range (- or /)  ->  ")
    _withPorts     = raw_input("Scan Ports Too? [y/n]            ->  ")
    print('SCAN -> Skipping Script Generation...\n')
    if(_withPorts == 'y' or _withPorts == 'Y'):
        print("SCAN -> WARNING -> Scanning with ports will require additional time...\n")
        os.system("nmap "+_attackAddress)
    else:
        os.system("nmap "+_attackAddress+" -sn")
    print("\n\nSCAN -> Complete. Review the results above.")