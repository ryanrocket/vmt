# Vu MultiTool
# Providing A Plethora of Local Host and Internet Wide Utilites
# SQL Port Scan Module

import sys
import os
import time
import socket
import random
import struct

def startProgress(title):
    global progress_x
    sys.stdout.write(title + " -> [" + "-"*45 + "]" + chr(8)*46)
    sys.stdout.flush()
    progress_x = 0

def progress(x,y):
    global progress_x
    x = int(x * 45 // y)
    sys.stdout.write("#" * (x - progress_x))
    sys.stdout.flush()
    progress_x = x

def endProgress():
    sys.stdout.write("#" * (45 - progress_x) + "]\n")
    sys.stdout.flush()

def multi_sps_main():
    print("-- -- -- -- -- -- --   Vu MultiTool   -- -- -- -- -- -- --")
    print('-- -- -- -- -- --    SQL Port Scanner    -- -- -- -- -- --\n')
    _attackAddress = raw_input("Enter IP Address       ->  ")
    startProgress("GENERATE")
    progress(1,5)
    time.sleep(2)
    progress(4,5)
    time.sleep(1)
    endProgress()
    print("SCAN -> Successfuly Generated Scan Script\n")
    time.sleep(1)
    print("SCAN -> Attempting for SQL on port 1433 [TCP]\n")
    os.system("nmap -p T:1433 -sV -sC "+_attackAddress)
    print("\n\nSCAN -> Attempting for MySQL on port 3306 [TCP]\n\n")
    os.system("nmap -p T:3306 -sV -sC "+_attackAddress)
    print("\n\nSCAN -> Completed. Please review the results above")
    print("SCAN -> Attempting to find MySQL Users\nSCAN -> WARNING -> This may take some time...\n\n")
    os.system("nmap -sV -sC --script mysql-audit,mysql-databases,mysql-dump-hashes,mysql-empty-password,mysql-enum,mysql-info,mysql-query,mysql-users,mysql-variables,mysql-vuln-cve2012-2122 "+_attackAddress)
    print('\nSCAN -> Completed. Please review the results above')
    print("SCAN -> Script Done.")