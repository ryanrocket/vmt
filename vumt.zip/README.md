# Vu Multi-Tool (VMT or VUMT)
### Providing a Plethora of Networking tools for PenTesting
#### By Ryan Wans

###### Usage of Vu Multi-Tool for attacking targets without prior mutual consent is illegal. It is the end user's responsibility to obey all applicable local, state and federal laws. Developers assume no liability and are not responsible for any misuse or damage caused by this program. By downloading and executing any of the provided files, you agree to the aforementioned terms and conditions.

## Features
* DoS Attack Tool
* Port Scanning Tool
* Retrieve IP from URL
* MAC Address Changer
* SQL Port Scanner 
* IP Scanner Tool
* Reverse IP Lookup
* Geolocate Personal Info
* Find Closest Icecream Store to IP Address
* More To Come!

## Dependencies
* Python 2.7
* NMAP

## Installation
* Clone Git    : `git clone https://github.com/ryanrocket/vumt.git`
* Change Dir   : `cd vumt`
* Run File     : `python vmt.py`


More updates on the way!
