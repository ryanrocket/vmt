# Vu MultiTool
# Providing A Plethora of Local Host and Internet Wide Utilites
# Local Port Scanner Module

import sys
import os
import time
import socket
import random
import struct
import threading

global _openPorts
global r

def startProgress(title):
    global progress_x
    sys.stdout.write(title + " -> [" + "-"*45 + "]" + chr(8)*46)
    sys.stdout.flush()
    progress_x = 0

def progress(x,y):
    global progress_x
    x = int(x * 45 // y)
    sys.stdout.write("#" * (x - progress_x))
    sys.stdout.flush()
    progress_x = x

def endProgress():
    sys.stdout.write("#" * (45 - progress_x) + "]\n")
    sys.stdout.flush()

def multi_lps_main():
    print("-- -- -- -- -- -- --   Vu MultiTool   -- -- -- -- -- -- --")
    print('-- -- -- -- -- -- --  Port Scan Tool  -- -- -- -- -- -- --\n')
    _attackAddress = raw_input("Enter IP Address            ->  ")
    _attackPort    =     input("Enter Max Port (Max 10000)  ->  ")
    _openPorts = []
    startProgress("SCAN")
    def _portTest(port):
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(0.4)
        try:
            con = s.connect((_attackAddress,port))
            _openPorts.append(port)
            con.close()
            return port
        except: 
            pass
    r = 1
    
    for x in range(1,_attackPort): 
        t = threading.Thread(target=_portTest,kwargs={'port':r}) 
        r += 1     
        t.start()
            
        progress(r, _attackPort)

    endProgress()
    print("SCAN -> [COMPLETED] "+str(r/10)+" Threads were used (per 10 ports)")
    print("SCAN -> [COMPLETED] "+str(_openPorts)+" Are The Available Ports\n")