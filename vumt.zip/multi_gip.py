# Vu MultiTool
# Providing A Plethora of Local Host and Internet Wide Utilites
# Hostname Resolver Module

import sys
import os
import time
import socket
import random
import struct
import threading

def multi_gip_main():
    print("-- -- -- -- -- -- --   Vu MultiTool   -- -- -- -- -- -- --")
    print('-- -- -- -- -- --    Hostname Resolver   -- -- -- -- -- --\n')
    a = raw_input("Enter URL  -->  ")
    print(socket.gethostbyname(a))