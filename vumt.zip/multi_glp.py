# Vu MultiTool
# Providing A Plethora of Local Host and Internet Wide Utilites
# Personal Info Lookup Module

import sys
import os
import time
import socket
import random
import struct
import webbrowser

def startProgress(title):
    global progress_x
    sys.stdout.write(title + " -> [" + "-"*45 + "]" + chr(8)*46)
    sys.stdout.flush()
    progress_x = 0

def progress(x,y):
    global progress_x
    x = int(x * 45 // y)
    sys.stdout.write("#" * (x - progress_x))
    sys.stdout.flush()
    progress_x = x

def endProgress():
    sys.stdout.write("#" * (45 - progress_x) + "]\n")
    sys.stdout.flush()

def multi_glp_main():
    print("-- -- -- -- -- -- --   Vu MultiTool   -- -- -- -- -- -- --")
    print('-- -- -- -- -- --  Personal Info Lookup  -- -- -- -- -- --\n')
    print("LOOKUP -> Please Note: This resource does not work on minors")
    print("LOOKUP ->              and depends on atleast 2 parameters")
    print("LOOKUP -> Please Note: Last Name + Zip = Most Accurate    \n")
    _url = str("https://www.whitepages.com/name/__a__/__b__?fs=1&l=__b__8&q=__a__")
    _lName = raw_input("Enter Last Name of Target  ->  ")
    _loc   = raw_input("State, City, or Zip Code   ->  ")
    _url = _url.replace('__a__', _lName)
    _url = _url.replace('__b__', _loc)
    print('\nLOOKUP -> You are being redirected to Whitepages for more info.')
    webbrowser.open(_url, new=0, autoraise=True)
